#!/bin/bash
### ===========================================================================
### Spatial registration
## required connectome workbench to be installed
### v4.0 202204
### ===========================================================================
BIDS_preprocessed_fMRI_before=/mnt/scratch/MBMv4/BIDS-preprocessed-volume-fMRI/noregr
BIDS_preprocessed_fMRI_after=/tmp
MBM_v3=/mnt/scratch/cirong/Marmoset_connectome/MBM_v3.0_beta_20200219


sub=sub-IONm01 # define the animal
ses=ses-01 # define the sessions
run=run-RL-1 #define the runs
inputdir=${BIDS_preprocessed_fMRI_before}/${sub}/${ses}
outputdir=${BIDS_preprocessed_fMRI_after}/${sub}/${ses}; mkdir -p ${outputdir}
MBMv3dir=${MBM_v3} # the MBMv3dir template folder
numCPU=8


## ======== estimate reg from fMRI to T2w ================================
wb_command -volume-to-surface-mapping ${inputdir}/${sub}_${ses}_task-rest_${run}.nii.gz ${MBMv3dir}/surfFS.lh.graymid.surf.gii ${outputdir}/${sub}_${ses}_task-rest_${run}_lh.func.gii -ribbon-constrained ${MBMv3dir}/surfFS.lh.white.surf.gii ${MBMv3dir}/surfFS.lh.pial.surf.gii 

wb_command -volume-to-surface-mapping ${inputdir}/${sub}_${ses}_task-rest_${run}.nii.gz ${MBMv3dir}/surfFS.rh.graymid.surf.gii ${outputdir}/${sub}_${ses}_task-rest_${run}_rh.func.gii -ribbon-constrained ${MBMv3dir}/surfFS.rh.white.surf.gii ${MBMv3dir}/surfFS.rh.pial.surf.gii 

#  # create a volume mask (for example the subcortical gray matter mask) to add the volume data into CIFTI
# fslmaths ${MBMv3dir}/segmentation_six_types_seg.nii.gz -thr 2 -uthr 2  ${MBMv3dir}/segmentation_six_types_seg_SUBC.nii.gz
# ResampleImage ${MBMv3dir}/segmentation_six_types_seg_SUBC.nii.gz 0.5x0.5x0.5 ${MBMv3dir}/segmentation_six_types_seg_SUBC.nii.gz 0 1

wb_command -cifti-create-dense-timeseries ${outputdir}/${sub}_${ses}_task-rest_${run}.dtseries.nii -volume ${inputdir}/${sub}_${ses}_task-rest_${run}.nii.gz ${MBMv3dir}/segmentation_six_types_seg_SUBC_iso05.nii.gz -left-metric ${outputdir}/${sub}_${ses}_task-rest_${run}_lh.func.gii -roi-left ${MBMv3dir}/surfFS.lh.MBM_cortex.shape.gii -right-metric  ${outputdir}/${sub}_${ses}_task-rest_${run}_rh.func.gii  -roi-right ${MBMv3dir}/surfFS.rh.MBM_cortex.shape.gii -timestep 2 

## smooth (optional)
# wb_command -cifti-smoothing ${outputdir}/${sub}_${ses}_task-rest_${run}.dtseries.nii 1 1 COLUMN ${outputdir}/${sub}_${ses}_task-rest_${run}_sm1.dtseries.nii  -left-surface ${MBMv3dir}/surfFS.lh.graymid.surf.gii -right-surface ${MBMv3dir}/surfFS.rh.graymid.surf.gii